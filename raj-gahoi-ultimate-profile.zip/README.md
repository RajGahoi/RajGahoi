<div align="center">

<img src="./assets/hero.svg" width="100%" alt="Raj Gahoi — Engineering / Building / Exploring"/>

<br/>

<img src="https://readme-typing-svg.herokuapp.com?font=Space+Mono&weight=700&size=20&duration=2200&pause=700&color=2563EB&center=true&vCenter=true&width=850&lines=I+BUILD+THINGS+I+WISH+EXISTED.;I+SOLVE+PROBLEMS+I+DON'T+UNDERSTAND+YET.;I+TURN+IDEAS+INTO+WORKING+SYSTEMS." />

<br/><br/>

<a href="https://github.com/RajGahoi"><img src="https://img.shields.io/badge/GITHUB-0F172A?style=for-the-badge&logo=github&logoColor=white"/></a>
<a href="https://leetcode.com/u/raj_gahoi/"><img src="https://img.shields.io/badge/LEETCODE-0F172A?style=for-the-badge&logo=leetcode&logoColor=FFA116"/></a>
<a href="https://www.linkedin.com/"><img src="https://img.shields.io/badge/LINKEDIN-0F172A?style=for-the-badge&logo=linkedin&logoColor=60A5FA"/></a>

</div>

---

<div align="center">

# ✦ NOT JUST ANOTHER DEVELOPER README.

### A little about the person behind the commits.

</div>

I'm **Raj Gahoi**, a CSE undergraduate who likes the part of software engineering where an empty folder slowly becomes something useful.

I spend my time around:

**Algorithms** · **Products** · **Web** · **Backend** · **AI** · **Security**

I learn by doing:

> **Question → Experiment → Build → Break → Understand → Improve**

---

## `// CURRENTLY IN THE LAB`

<table>
<tr>
<td width="25%" align="center">

### 🧠
**DSA**

Patterns  
Algorithms  
CP

</td>
<td width="25%" align="center">

### ◈
**WEB**

React  
JavaScript  
UI

</td>
<td width="25%" align="center">

### ⚙
**BACKEND**

APIs  
Databases  
Systems

</td>
<td width="25%" align="center">

### ✦
**AI**

ML  
Automation  
Intelligence

</td>
</tr>
</table>

---

<div align="center">

<img src="./assets/projects.svg" width="100%" alt="Selected projects"/>

</div>

---

# `01 / SENTINAL MINDS`

### **AI × CYBERSECURITY**

A security-focused platform built around **threat analysis, investigation and actionable intelligence**.

```text
THREAT
   ↓
EVIDENCE
   ↓
ANALYSIS
   ↓
INTELLIGENCE
   ↓
DECISION
   ↓
ACTION
```

`AI` `Cybersecurity` `Automation`

[ **SOURCE →** ](https://github.com/RajGahoi)

---

# `02 / PHISHNET SENTINALS`

### **INTELLIGENT PHISHING DEFENSE**

A cybersecurity project focused on detecting and analyzing phishing threats.

```text
INPUT → INSPECT → EXTRACT SIGNAL → CLASSIFY → RESPOND
```

`Security` `Web` `Threat Detection`

[ **SOURCE →** ](https://github.com/RajGahoi)

---

# `03 / LECTURE2PDF AI`

### **TURNING LECTURES INTO SOMETHING YOU CAN SEARCH**

A Chrome extension that converts lecture videos into structured PDFs by detecting meaningful lecture slides.

**The idea**

```text
        🎥 VIDEO
           │
           ▼
    ┌───────────────┐
    │ SLIDE ENGINE  │
    └───────┬───────┘
            ▼
    ┌───────────────┐
    │  PROCESSING   │
    └───────┬───────┘
            ▼
    ┌───────────────┐
    │  PDF ENGINE   │
    └───────┬───────┘
            ▼
           📄
```

`JavaScript` `Chrome Extension` `AI` `PDF`

[ **SOURCE →** ](https://github.com/RajGahoi)

---

<div align="center">

# `THE PROBLEM SOLVING ROOM`

### I don't collect solved problems.  
### I collect patterns.

<img src="https://leetcard.jacoblin.cool/raj_gahoi?theme=dark&font=Space%20Mono&ext=contest"/>

<br/><br/>

`UNDERSTAND` → `PATTERN` → `APPROACH` → `OPTIMIZE` → `CODE`

</div>

---

# `THE TOOLBOX`

<div align="center">

<img src="https://skillicons.dev/icons?i=c,cpp,java,python,js,ts,html,css,react,tailwind,nodejs,express,fastapi,postgres,redis,docker,git,github,postman,vscode&perline=10&theme=light"/>

</div>

---

<div align="center">

# `GITHUB / ACTIVITY`

<img width="49%" src="https://github-readme-stats.vercel.app/api?username=RajGahoi&show_icons=true&include_all_commits=true&hide_border=true&bg_color=F8FAFC&title_color=0F172A&text_color=475569&icon_color=2563EB&rank_icon=github"/>

<img width="49%" src="https://streak-stats.demolab.com?user=RajGahoi&theme=default&hide_border=true&background=F8FAFC&ring=2563EB&fire=7C3AED&currStreakLabel=0F172A"/>

<br/><br/>

<img width="97%" src="https://github-readme-activity-graph.vercel.app/graph?username=RajGahoi&bg_color=F8FAFC&color=334155&line=2563EB&point=7C3AED&area=true&hide_border=true"/>

</div>

---

<div align="center">

# `CONTRIBUTION TRAIL`

<img src="https://raw.githubusercontent.com/RajGahoi/RajGahoi/output/github-contribution-grid-snake-dark.svg" alt="GitHub contribution snake"/>

</div>

---

## `THE ROAD AHEAD`

```text
                    DSA
                     │
                     ▼
              PROBLEM SOLVING
                     │
                     ▼
               FULL STACK
                     │
                     ▼
                 BACKEND
                     │
                     ▼
              SYSTEM DESIGN
                     │
                     ▼
                  AI / ML
                     │
                     ▼
             SOFTWARE ENGINEERING
```

---

<div align="center">

## A FEW RULES I TRY TO FOLLOW

**Build before you overthink.**

**Understand before you copy.**

**Debug before you blame the code.**

**Ship before you call it finished.**

<br/>

`CURIOUS` · `CONSISTENT` · `HUNGRY TO BUILD`

</div>

---

<div align="center">

### FIND ME

<a href="https://github.com/RajGahoi"><img src="https://img.shields.io/badge/GitHub-0F172A?style=for-the-badge&logo=github&logoColor=white"/></a>
<a href="https://leetcode.com/u/raj_gahoi/"><img src="https://img.shields.io/badge/LeetCode-0F172A?style=for-the-badge&logo=leetcode&logoColor=FFA116"/></a>
<a href="https://www.linkedin.com/"><img src="https://img.shields.io/badge/LinkedIn-0F172A?style=for-the-badge&logo=linkedin&logoColor=60A5FA"/></a>

<br/><br/>

<img src="https://readme-typing-svg.herokuapp.com?font=Space+Mono&weight=700&size=17&duration=2600&pause=900&color=2563EB&center=true&vCenter=true&width=720&lines=Thanks+for+stopping+by.;Now+go+build+something+interesting.;See+you+in+the+next+commit." />

<br/><br/>

### `BUILD  /  SOLVE  /  SHIP  /  REPEAT`

</div>
